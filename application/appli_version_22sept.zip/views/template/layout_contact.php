<?php
$this->load->view('template/header_front');
$this->load->view('template/bann_c');
$this->load->view('template/navigation_bar_front');
$this->load->view($contents);
$this->load->view('template/footer_front'); 