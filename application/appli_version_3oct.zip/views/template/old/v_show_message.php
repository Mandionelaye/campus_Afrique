<div class="row">
	<div class="col-md-2">
	</div>


	<!-- Standard Alert -->
	<div class="col-md-8">
		<div class="panel panel-default">
			<div class="panel-heading"> 
				<h3 class="panel-title"><?php echo $title  ?> </h3> 
			</div> 
			<div class="panel-body"> 
			
				<div class="alert alert-<?php echo $status  ?>">
<?php echo $message  ?> 
				</div>



			</div>  <!-- Panel-body -->
		</div> <!-- Panel-->
	</div>
	
	
	
	<div class="col-md-2">
	</div>



</div>