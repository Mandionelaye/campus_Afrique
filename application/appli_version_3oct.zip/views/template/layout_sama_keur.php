<?php
$this->load->view('template/header_smk');
$this->load->view('template/navigation_bar_smk');
$this->load->view($contents);
$this->load->view('template/footer'); 
