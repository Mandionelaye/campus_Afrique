<?php
$this->load->view('template/header');
$this->load->view('template/navigation_bar');
$this->load->view($contents);
$this->load->view('template/footer'); 
