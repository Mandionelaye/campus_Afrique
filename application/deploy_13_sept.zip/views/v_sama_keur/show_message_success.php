


<div class="card" align='center'>
	<div class="card-body">
	  <h5 class="card-title">Votre compte à été crée avec succés merci de consulter votre email</h5>

	  <!-- Growing Color spinnersr -->

	  <div class="spinner-grow text-success" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 

	  <div class="spinner-grow text-success" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 

	  <div class="spinner-grow text-success" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>


			<p>&nbsp; </p>


			<div class="alert alert-success alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">Message de confirmation</h4>
                <p>Félicitation votre compte à été crée avec succès</p>
                <hr>
                <p class="mb-0">Vous pouvez maintenant vous connecter.</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
			  
			<div >
			<a href="<?php echo site_url('acceder-a-son-espace') ?>" ; >
				<button type="button" class="btn btn-success">Se connecter </button>
			</a>
			
			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
			<a href='./'>
				<button type="button" class="btn btn-info">Retourner à l'accueil </button>
			</a>
			</div>

	</div>
  </div>


