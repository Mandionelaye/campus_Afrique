


<div class="card" align='center'>
	<div class="card-body">
	  <h5 class="card-title">Vous ne pouvez plus déposer</h5>

	  <!-- Growing Color spinnersr -->

	  <div class="spinner-grow text-danger" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 

	  <div class="spinner-grow text-danger" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 



			<p>&nbsp; </p>


			<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">Message d'informations</h4>
                <p>Un seul dépot est possible pour une offre donné, bonne chance!!!</p>
                <hr>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
			  
			<div >
			<a href="<?php echo site_url('candidat-liste-des-offres') ?>" ; >
				<button type="button" class="btn btn-warning">Retourner </button>
			</a>
			
			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
			<!--a href='./'>
				<button type="button" class="btn btn-info">Retourner à l'accueil </button>
			</a-->
			</div>

	</div>
  </div>
</main>