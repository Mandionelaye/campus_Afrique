


<div class="card" align='center'>
	<div class="card-body">
	  <h5 class="card-title">Mauvaises paramétres</h5>

	  <!-- Growing Color spinnersr -->

	  <div class="spinner-grow text-danger" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 

	  <div class="spinner-grow text-danger" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>

&nbsp; &nbsp; &nbsp; &nbsp; 

	  <div class="spinner-grow text-danger" role="status">
		<span class="visually-hidden">Loading...</span>
	  </div>


			<p>&nbsp; </p>


			<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">Erreur paramétres</h4>
                <p>Attention!mot de pass incorrect</p>
                <hr>
                <p class="mb-0">Aprés 3 tentatives votre compte sera bloqué!.</p>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
			  
			<div >
			<a href="<?php echo site_url('wethio-thiabi') ?>" ; >
				<button type="button" class="btn btn-success">Réessayer</button>
			</a>
			
			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
			<a href='mon-profil'>
				<button type="button" class="btn btn-info">Retourner à l'accueil </button>
			</a>
			</div>

	</div>
  </div>