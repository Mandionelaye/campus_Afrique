   
  <div class="" style="margin-top:60px">
    <section class="slider_section">
      <div class="slider_container" style="background-image: url(assets/img/sep1.png);" >
        <div id="carouselExampleIndicators"  class="carousel slide" data-ride="carousel">
          <div class="carousel-inner"  >
            <div class="carousel-item active">
              <div class="container-fluid">
                <div class="row" >
                  <div class="col-md-12" >
                    <div class="detail-box text-center" >
                      <h1>
                       Vous souhaitez nous contacter !!!
                        
                      </h1>
                      <p> Envoyez nous un mail</p>
                      
                      <a href="https://www.perfplustech.com/" target="_blank">En savoir plus sur Performance Plus</a>
                   
                    </div>
                  </div>
                  </div -->
                </div>
              </div>
            </div>
         
          </div>
         
        </div>
      </div>
    </section>
  </div>
