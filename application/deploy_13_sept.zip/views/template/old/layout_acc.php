<?php
$this->load->view('template/header');
$this->load->view($contents);
$this->load->view('template/footer');
$this->load->view('template/morris');

?>
