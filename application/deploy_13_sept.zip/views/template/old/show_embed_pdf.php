


<iframe src="<?php echo $file_pdf; ?>" title="DEFCCS" width="100%" height="100%" style="border:1px solid black;"></iframe>